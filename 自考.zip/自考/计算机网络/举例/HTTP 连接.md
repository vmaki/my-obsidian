## 非持久连接的HTTP（HTTP1.0 - TCP用1次就断开）
> 客户与服务器建立TCP连接后，通过该连接发送HTTP请求报文，接收HTTP响应报文，然后断开TCP连接

### 一条连接

==用一次断一次==

<img src="https://vmaki-blog.oss-cn-hangzhou.aliyuncs.com/image-20220927123102995.png" alt="image-20220927123102995" style="zoom:25%;" />

### 多条连接(并行连接)

> 建立多条并行TCP连接，并行发送HTTP请求和并行接收HTTP响应。然后断开TCP连接

==并行多条，用一次断一次==

<img src="https://vmaki-blog.oss-cn-hangzhou.aliyuncs.com/image-20220927123131279.png" alt="image-20220927123131279" style="zoom:25%;" />

## 持久连接的HTTP（HTTP1.1 - TCP不断开）

### 非流水方式持久连接

> 建立TCP连接，发送请求和接收响应后，不断开TCP连接，继续请求

==不断开，不并行==

<img src="https://vmaki-blog.oss-cn-hangzhou.aliyuncs.com/image-20220927123158392.png" alt="image-20220927123158392" style="zoom:25%;" />

### 流水方式持久连接

==不断开，并行==

<img src="https://vmaki-blog.oss-cn-hangzhou.aliyuncs.com/image-20220927123234666.png" alt="image-20220927123234666" style="zoom:25%;" />