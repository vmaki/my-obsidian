## 套接字(socket)

> 套接字(Socket): 典型的网络应用编程接口

### Socket API函数

- 创建套接字: `socket( )`
	- 数据报类型套接字(`SOCK_DGRAM`): 网络应用进程可以创建的面向传输层`UDP`接口
	- 流式套接字(`SOCK_STREAM`):  网络应用进程可以创建的面向传输层`TCP`接口
	- 原始套接字(`SOCK_RAW`)
- 绑定套接字的本地端点地址: ` bind( )`
- 设置监听: `listen( )`
- 建立连接：
	- TCP客户端: `connect( )`
	- TCP服务端: `accept( )`
- 接收数据：
	- TCP: `recv( ) `
	- UDP:`recvfrom`
- 发送数据：
  - TCP: `send( )`` 
  - UDP: `sendto`
- 关闭套接字：close( )

## 端口号

> 端口号：标识套接字的编号

### 常用端口号

- 20(数据)、21(控制): FTP文件传输协议端口号
- 25: SMTP简单邮件传输协议端口号
- 53: DNS域名服务器端口号
- 80: HTTP超文本传输协议端口号
- 110: POP3第三版的邮局协议端口号